//
//  ViewController.swift
//  Pre_work_app
//
//  Created by George Lu on 9/30/18.
//  Copyright © 2018 George Lu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var textLabel: UILabel!
    @IBOutlet weak var textField: UITextField!
    
    var backgroundColor: UIColor!
    var textColor: UIColor!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        backgroundColor = view.backgroundColor;
        textColor = textLabel.textColor;
    }

    @IBAction func buttonTapped(_ sender: Any) {
        print("Text color changed")
        textLabel.textColor = getRandomColor()
    }
    
    @IBAction func viewChangeButtonTapped(_ sender: Any) {
        print("Background color changed")
        view.backgroundColor = getRandomColor()
    }
    
    @IBAction func changeTextButtonTapped(_ sender: Any) {
        if(textField.text == ""){
            textLabel.text = "Goodbye 👋"
            view.endEditing(true)
        }
        else{
            textLabel.text = textField.text;
            textField.text = ""
            view.endEditing(true)
        }
    }
    
    @IBAction func tapBackGroundToReset(_ sender: Any) {
        textLabel.text = "Hello"
        view.backgroundColor = backgroundColor
        textLabel.textColor = textColor
    }
    
    func getRandomColor() -> UIColor {
        //Generate between 0 to 1
        let red:CGFloat = CGFloat(drand48())
        let green:CGFloat = CGFloat(drand48())
        let blue:CGFloat = CGFloat(drand48())
        
        return UIColor(red: red, green: green, blue: blue, alpha: 1.0)
    }
    
}

